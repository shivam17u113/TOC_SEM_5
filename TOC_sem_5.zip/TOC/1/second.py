d={}
states=list(input("enter the states ").split())

for i in states:
 d[i]=[]
 d[i].append(set(input('ENter the states which are rechable from '+ i +'for  input 0').split()))

 d[i].append(set(input("ENter the states which are rechable from "+i+" for  input 1").split()))

print(d)
newd={}
newstates=[]
newstates.append(states[0])

for j in newstates:
	un=set()
	newd[j]=[]
	for i in j:
		un=un.union(d[i][0])
	newd[j].append(''.join(un))
	if (''.join(un)) not in newstates:
		if len(un) !=0:
			newstates.append(''.join(un))
 
	un=set()
	for i in j:
		un=un.union(d[i][1])
	newd[j].append(''.join(un))
	if (''.join(un)) not in newstates:
		if len(un)!=0:
			newstates.append(''.join(un))

for k in newd.keys():
	print(k,'--->',newd[k])







