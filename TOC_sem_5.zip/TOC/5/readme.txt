to run yacc program use follwog comands:

1. lex codel.l
2. yacc -d codey.y
3. gcc lex.yy.c y.tab.c

